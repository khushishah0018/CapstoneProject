import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-get-orders',
  templateUrl: './get-orders.component.html',
  styleUrls: ['./get-orders.component.scss']
})
export class GetOrdersComponent implements OnInit {

  formModel: any = { status: null };
  showError: boolean = false;
  errorMessage: any;
  orderList: any = [];
  assignModel: any = {};

  showMessage: any;
  responseMessage: any;
  updateId: any;
  newOrder: any;

  constructor(
    public router: Router,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.getOrders();
  }

  getOrders() {
    const userIdString = localStorage.getItem('userId');
    const userId = userIdString ? parseInt(userIdString, 10) : null; 
    this.httpService.getOrderByWholesalers(userId).subscribe(
      {
        next:(data: any) => {
      this.orderList = data;
      console.log(this.orderList);
    }, error:(error) => {
      this.showError = true;
      this.errorMessage = "An error occurred. Please try again later.";
      console.error('Error:', error);
    }});
  }

  processOrder(value: any) {
    this.newOrder = value;
    this.updateId = value.id;
  }

  onSubmit() {
    if (this.formModel.status) {
      this.showError = false;
      this.httpService.updateOrderStatus(this.updateId, this.formModel.status).subscribe(
        {
          next:(data: any) => {
        console.log(data);
        this.updateId = null;
        this.formModel = {};
        this.formModel.status = null;
        this.getOrders();
      }, error:(error) => {
        this.showError = true;
        this.errorMessage = "An error occurred while updating the order. Please try again later.";
        console.error('Error:', error);
      }});
    }
  }
}