import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  itemForm: FormGroup;
  formModel: any = { role: null, email: '', password: '', username: '' };
  showMessage: boolean = false;
  responseMessage: any;
  showError: boolean = false;
  errorMessage: any;

  constructor(
    public router: Router,
    private bookService: HttpService,
    private formBuilder: FormBuilder
  ) {
    this.itemForm = this.formBuilder.group({
      email: [this.formModel.email, [Validators.required, Validators.email]],
      password: [this.formModel.password, [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_+])[a-zA-Z\d!@#$%^&*_+]{8,}$/)]],
      role: [this.formModel.role, [Validators.required]],
      username: [this.formModel.username, [Validators.required, Validators.pattern(/^[a-zA-Z\d]+$/)]],
    });
  }

  ngOnInit(): void {}

  onRegister() {
    if (this.itemForm.valid) {
      this.showMessage = false;
      this.bookService.registerUser(this.itemForm.value).subscribe(

        {
          next:(data) => {
          this.showMessage = true;
          this.responseMessage = 'You are successfully registered';
          this.itemForm.reset();
        },
        error:(error) => {
          this.showError = true;
          console.log(error);
          this.errorMessage = 'Username Already Exists!';
          setTimeout(()=>{
            this.itemForm.reset();
            this.showError = false;
          }, 2000);
        }}
      );
    } else {
      this.itemForm.markAllAsTouched();
    }
  }
}