
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-create-products',
  templateUrl: './create-products.component.html',
  styleUrls: ['./create-products.component.scss']
})
export class CreateProductsComponent implements OnInit {
  itemForm: FormGroup;
  formModel: any = { status: null };
  showError: boolean = false;
  errorMessage: any;
  productList: any = [];
  assignModel: any = {};
  showMessage: any;
  responseMessage: any;
  updateId: any;

  constructor(
    public router: Router,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    this.itemForm = this.formBuilder.group({
      id:[''],
      name: [this.formModel.name, [Validators.required]],
      description: [this.formModel.description, [Validators.required]],
      price: [this.formModel.price, [Validators.required,Validators.min(1)]],
      stockQuantity: [this.formModel.stockQuantity, [Validators.required,Validators.min(1)]],
      manufacturerId: [this.formModel.manufacturerId],
    });
  }

  ngOnInit(): void {
    this.getProducts();
  }

  onSubmit() {
    if (this.itemForm.valid) {
      this.showError = false;
      const userIdString = localStorage.getItem('userId');
      const userId = userIdString ? parseInt(userIdString, 10) : null;
      this.itemForm.controls["manufacturerId"].setValue(userId);

      if (this.updateId > 0) {
        this.httpService.updateProduct(this.updateId,this.itemForm.value).subscribe(
          {
          next:(data: any) => {
            this.itemForm.reset();
            this.getProducts();
          },
          error: (error) => {
            this.showError = true;
            this.errorMessage = "An error occurred while updating the product. Please try again later.";
            console.error('Error:', error);
          }}
        );
      } else {
        this.httpService.createProduct(this.itemForm.value).subscribe(
          {
          next:(data: any) => {
            this.itemForm.reset();
            this.getProducts();
          },
          error:(error) => {
            this.showError = true;
            this.errorMessage = "An error occurred while creating the product. Please try again later.";
            console.error('Error:', error);
          }}
        );
      }
    } else {
      this.itemForm.markAllAsTouched();
    }
  }

  edit(product: any) {
    this.itemForm.patchValue(product);
    this.updateId = product.id;
  }

  getProducts() {
    this.productList = [];
    const userIdString = localStorage.getItem('userId');
    const userId = userIdString ? parseInt(userIdString, 10) : null;
    this.httpService.getProductsByManufacturer(userId).subscribe(
      {
      next:(data: any) => {
        this.productList = data;
        console.log(this.productList);
      },
      error:(error) => {
        this.showError = true;
        this.errorMessage = "An error occurred while fetching products. Please try again later.";
        console.error('Error:', error);
      }}
    );
  }



delete(pro: any)
  {
    let prodId = pro.id
    this.httpService.deleteProduct(prodId).subscribe(
      {
        next: (data)=>
        {
          console.log(data);
        this.getProducts();
        },
        error: (error)=>
        {
          console.log(error);
        }
     
      }
    );
   
  }


}


