import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  styleUrls: ['./add-inventory.component.scss']
})
export class AddInventoryComponent implements OnInit {

  itemForm!: FormGroup; 
  formModel: any = { status: null };
  showError: boolean = false;
  errorMessage: any;
  productList: any[] = [];
  assignModel: any = {};

  showMessage: any;
  responseMessage: any;
  eventList: any = [];
  orderList: any = [];
  inventoryList : any[] = [];
  updateId: any;
  productDis:any;

  constructor(
    public router: Router,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    this.itemForm = this.formBuilder.group({
      wholesalerId: [this.formModel.wholesalerId],
      stockQuantity: [this.formModel.stockQuantity, [Validators.required]],
      productId: [this.formModel.productId, [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.getProducts();
    this.getInventory();
    this.getOrders(); // Fetch orders on initialization
    
    

  }

  onSubmit() {
    if (this.itemForm.valid) {
      if (this.updateId > 0) {
        this.showError = false;
        const userIdString = localStorage.getItem('userId');
        const userId = userIdString ? parseInt(userIdString, 10) : null; 
        this.itemForm.controls["wholesalerId"].setValue(userId);
        this.httpService.updateInventory(this.itemForm.controls["stockQuantity"].value, this.updateId).subscribe(
          {
            next:(data: any) => {
          //this.itemForm.reset();
          this.showMessage = true;
          this.responseMessage = 'Updated Successfully';
          this.getInventory();
        }, error:(error) => {
          this.showError = true;
          this.errorMessage = "An error occurred while logging in. Please try again later.";
          console.error('Login error:', error);
        }});
      } else {
        this.showError = false;
        const userIdString = localStorage.getItem('userId');
        const userId = userIdString ? parseInt(userIdString, 10) : null; 
        this.itemForm.controls["wholesalerId"].setValue(userId);
        console.log(this.itemForm.value);
        this.httpService.addInventory(this.itemForm.value, this.itemForm.controls["productId"].value).subscribe(
          {
            next:(data: any) => {
          this.itemForm.reset();
          this.showMessage = true;
          this.getInventory();
          this.responseMessage = 'Save Successfully';
        }, error: (error) => {
          this.showError = true;
          this.errorMessage = "An error occurred while logging in. Please try again later.";
          console.error('Login error:', error);
        }});
      }
    } else {
      this.itemForm.markAllAsTouched();
    }
  }

  getInventory() {

    //let userId:number = +(localStorage.getItem('userId'))
    console.log("Inside get Inventory");
    const userIdString = localStorage.getItem('userId');
    const userId = userIdString ? parseInt(userIdString, 10) : null; 
    this.httpService.getInventoryByWholesalers(userId).subscribe(
      {
        next:(data) => {
          console.log(data);
      this.inventoryList = data;
      console.log("orderList");
      
      console.log(this.orderList);
    }, error: (error) => {
      this.showError = true;
      this.errorMessage = "An error occurred.. Please try again later.";
      console.error('Login error:', error);
    }});
  }

  getProducts() {
    this.productList = [];
    console.log("Inside get Products Method")
    this.httpService.getProductsByWholesaler().subscribe(
      {
        next:(data: any) => {
      this.productList = data;
      console.log(this.productList);
    }, error:(error) => {
      this.showError = true;
      this.errorMessage = "An error occurred while logging in. Please try again later.";
      console.error('Login error:', error);
    }});
  }

  getOrders() {
    console.log("Inside getOrders Method");
    const userIdString = localStorage.getItem('userId');
    const userId = userIdString ? parseInt(userIdString, 10) : null; 
    this.httpService.getOrderByWholesalers(userId).subscribe(
      {
        next:(data: any) => {
      console.log("Inside GetOrder By Wholesaler");
      this.orderList = data;
      console.log(this.orderList);
    }, error:(error) => {
      this.showError = true;
      this.errorMessage = "An error occurred. Please try again later.";
      console.error('Error:', error);
    }});
  }

  editInventory(value: any) {
    this.updateId = value.id;
    this.itemForm.patchValue({
      productId: value.id,
      stockQuantity: value.stockQuantity,
      wholesalerId: value.wholesalerId
    });
  }

  selectProduct(value:any){
    let productId:number = value;
    console.log(productId);
    
    console.log(this.productList);
    
    this.productDis = this.productList.find(p=>p.id==productId);
    console.log(this.productDis);
    

    // this.productDis = value;
    // console.log("form");
    
    
    // console.log(value);
    // console.log("object");
    // console.log(this.productDis);
  }

}
