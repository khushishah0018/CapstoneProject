import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-consumer-place-order',
  templateUrl: './consumer-place-order.component.html',
  styleUrls: ['./consumer-place-order.component.scss']
})
export class ConsumerPlaceOrderComponent implements OnInit {
 checkQuantity:number=0;
  itemForm: FormGroup; 
  formModel: any = { status: null };
  showError: boolean = false;
  errorMessage: any;
  productList: any = [];
  assignModel: any = {};
  orderDis: any;
  showMessage: any;
  responseMessage: any;
  productId: any;

  constructor(
    public router: Router,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    this.itemForm = this.formBuilder.group({
      quantity: [this.formModel.quantity, [Validators.required,this.maxQuantity,Validators.min(1)]],
      status: [this.formModel.status, [Validators.required]]
    });
  }

  maxQuantity(cont: AbstractControl): ValidationErrors | null
  {
    const val = cont.value;
    if( val < cont.value)
    {
      return {'value': true};
    }
    return null;
  }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts() {
    this.productList = [];
    this.httpService.getProductsByConsumers().subscribe((data: any) => {
      this.productList = data;
      console.log(this.productList);
    }, error => {
      this.showError = true;
      this.errorMessage = "An error occurred. Please try again later.";
      console.error('Error:', error);
    });
  }

  onSubmit() {
    if (this.productId) {
      
      if (this.itemForm.valid) {
        if(this.checkQuantity< this.itemForm.value.quantity)
        {
          alert("Requested Quantity exceeds the Existing Quantity");
        }
        else
        {
        this.showError = false;
        const userIdString = localStorage.getItem('userId');
        const userId = userIdString ? parseInt(userIdString, 10) : null; 
        this.httpService.consumerPlaceOrder(this.itemForm.value, this.productId, userId).subscribe((data: any) => {
          this.itemForm.reset();       
          this.productId = null;
          this.responseMessage = "Order placed Successfully";
        }, error => {
          this.showError = true;
          this.errorMessage = "An error occurred while creating the order. Please try again later.";
          console.error('Error:', error);
        });
      }} else {
        this.itemForm.markAllAsTouched();
      }
    }
  }

  addToOrder(val: any) {
    console.log(val);
    this.orderDis = val;
    this.productId = val.id;
    this.checkQuantity=this.orderDis.stockQuantity;
    console.log(this.checkQuantity);
    // this.httpService.getInventory(this.productId).subscribe((data)=>{

    // })
  }}