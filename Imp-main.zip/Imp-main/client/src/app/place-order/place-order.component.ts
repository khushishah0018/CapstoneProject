
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.scss']
})
export class PlaceOrderComponent implements OnInit {
  itemForm: FormGroup; 
  formModel: any = { status: null };
  showError: boolean = false;
  errorMessage: any;
  productList: any = [];
  assignModel: any = {};
  showMessage: any;
  responseMessage: any;
  productId: any;
  assignedStockQuantity: any;
  localProduct:any;

  constructor(
    public router: Router,
    public httpService: HttpService,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    this.itemForm = this.formBuilder.group({
      quantity: [this.formModel.quantity, [Validators.required,Validators.min(1)]],
      status: [this.formModel.status, [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts() {
    this.productList = [];
    this.httpService.getProductsByWholesaler().subscribe((data: any) => {
      this.productList = data;
      console.log(this.productList);
    }, error => {
      this.showError = true;
      this.errorMessage = "An error occurred. Please try again later.";
      console.error('Login error:', error);
    });
  }

  onSubmit() {
    
    if (this.productId) {
      if (this.itemForm.valid) {
        const order = this.itemForm.value;
        if(order.quantity > this.assignedStockQuantity)
        {
          alert("Requested Quantity is more than Assigned.");
          this.itemForm.reset();
        }
        else{


        this.showError = false;
        const userIdString = localStorage.getItem('userId');
        const userId = userIdString ? parseInt(userIdString, 10) : null; 
        
        this.httpService.placeOrder(this.itemForm.value, this.productId, userId).subscribe(
          {
            next: (data: any) => {
          //this.itemForm.reset();       
          this.productId = null;
          this.responseMessage = "Order placed Successfully";

          console.log("before update");
          console.log(this.localProduct);
          
          
          this.localProduct.stockQuantity = this.localProduct.stockQuantity-this.itemForm.value.quantity;
          console.log("qty check");
          console.log(this.itemForm.value);
          
          console.log(this.localProduct.stockQuantity);
          
          console.log(this.itemForm.value.quantity);
          
          console.log(this.localProduct.stockQuantity);
          
          
          this.httpService.updateProduct(this.localProduct.id,this.localProduct).subscribe((data)=>{
            console.log("inside update sub");
            console.log(data);
            
            
            this.getProducts()
          });
          console.log("after update");
          console.log(this.localProduct);
          
          

        }, error: (error) => {
          this.showError = true;
          this.errorMessage = "An error occurred while creating the order. Please try again later.";
          console.error('Login error:', error);
        }});
      }
      } else {
        this.itemForm.markAllAsTouched();
      }
    }
  }

  addToOrder(val: any) {

    this.localProduct=val;
    this.productId = this.localProduct.id;
    this.assignedStockQuantity =this.localProduct.stockQuantity;

    // val.stockQuantity=val.stockQuantity-this.itemForm.value.quantity;
    // this.httpService.updateProduct(val.id,val).subscribe(()=>this.getProducts());
  }
}