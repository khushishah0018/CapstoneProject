import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { HttpService } from '../../services/http.service';

@Component({
  selector: 'app-dashbaord',
  templateUrl: './dashbaord.component.html',
  styleUrls: ['./dashbaord.component.scss']
})
export class DashbaordComponent  implements OnInit{

  manufacturerList: any = [];
  wholesalerList: any = [];
  consumerList: any = [];
  role!: any;
  isLoggedIn!:Boolean;

  feedBackList: any = [];
constructor(private httpService: HttpService, private authService: AuthService, private rou: Router){
  // this.role = localStorage.getItem('role');
  // console.log(this.role)
  this.isLoggedIn=this.authService.getLoginStatus;
  if(this.isLoggedIn){
    this.role=this.authService.getRole;
  }
}
  ngOnInit(): void {
    this.getFeedbacks();
  }
  getFeedbacks()
  {
    this.httpService.getAllFeedbacks().subscribe((data)=>
    {
      this.feedBackList=data;
    })
  }
}
