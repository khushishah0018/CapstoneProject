import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from '../../services/http.service';
import { AuthService } from '../../services/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-consumer-get-orders',
  templateUrl: './consumer-get-orders.component.html',
  styleUrls: ['./consumer-get-orders.component.scss'],
  providers: [DatePipe]
})
export class ConsumerGetOrdersComponent implements OnInit {

  formModel: any = {};
  showError: boolean = false;
  errorMessage: any;
  orderList: any = [];
  assignModel: any = {};
  feedBackList: any = [];
  showMessage: any;
  responseMessage: any;
  updateId: any;

  constructor(
    private datePipe: DatePipe,
    public router: Router,
    public httpService: HttpService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.getOrders();
    this.getFeedbacks();
  }

  getOrders() {
    this.orderList = [];
    const userIdString = localStorage.getItem('userId');
    const userId = userIdString ? parseInt(userIdString, 10) : null; 
    this.httpService.getOrderConsumer(userId).subscribe((data: any) => {
      this.orderList = data;
      console.log(this.orderList);
    }, error => {
      this.showError = true;
      this.errorMessage = "An error occurred. Please try again later.";
      console.error('Error:', error);
    });
  }

  getFeedbacks()
  {
    this.httpService.getAllFeedbacks().subscribe((data)=>
    {
      this.feedBackList=data;
    })
  }

  addFeedback(value: any) 
  {  
    this.updateId = value.id;
  }

  onSubmit() {
    if (this.formModel.content) {
      this.showError = false;
      const userIdString = localStorage.getItem('userId');
      const userId = userIdString ? parseInt(userIdString, 10) : null; 
      const formattedTime = this.datePipe.transform(new Date(), 'yyyy-MM-ddTHH:mm:ss.SSS');
      this.formModel.timestamp = formattedTime;

      this.httpService.addConsumerFeedBack(this.updateId, userId, this.formModel).subscribe((data: any) => {
        console.log(data);
        this.updateId = null;
        this.formModel = {};
        this.formModel.status = null;
        this.responseMessage = "Saved Successfully.";
      }, error => {
        this.showError = true;
        this.errorMessage = "An error occurred while creating feedback. Please try again later.";
        console.error('Error:', error);
      });
    }
  }
}