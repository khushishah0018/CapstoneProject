import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment.development';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  public serverName=environment.apiUrl;
  constructor(private http: HttpClient, private authService:AuthService) {

   }
 //done
  getProductsByWholesaler():Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/wholesalers/products`,{headers:headers});
  }
  //done
  getProductsByConsumers():Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/consumers/products`,{headers:headers});
  }

  getAllFeedbacks(): Observable<any>
  {
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/consumers/order/feedback/`,{headers:headers});
  }

  
  getOrderByWholesalers(id:any):Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/wholesalers/orders?userId=${id}`,{headers:headers});
  }
  //done
  getOrderConsumer(id:any):Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/consumers/orders?userId=${id}`,{headers:headers});
  }
  //get inventory by wholesaler
  getInventoryByWholesalers(id:any):Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/wholesalers/inventories?wholesalerId=${id}`,{headers:headers});
  }
  getInventory(id:any):Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/consumers/inventory/`+id,{headers:headers});
  }
 
  getProductsByManufacturer(id:any):Observable<any> {
   
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`)
    return this.http.get(this.serverName+`/api/manufacturers/products?manufacturerId=`+id,{headers:headers});
  }

  placeOrder(details:any,productId:any,userId:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.post(this.serverName+`/api/wholesalers/order?productId=${productId}&userId=${userId}`,details,{headers:headers});
  }
  
  consumerPlaceOrder(details:any,productId:any,userId:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.post(this.serverName+`/api/consumers/order?productId=${productId}&userId=${userId}`,details,{headers:headers});
  }
  //done//
  updateOrderStatus(id:any,status:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.put(this.serverName+`/api/wholesalers/order/${id}?status=`+status,{},{headers:headers});
  }
  
  //done
  addConsumerFeedBack(id:any,userId:any,details:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.post(this.serverName+`/api/consumers/order/${id}/feedback?userId=`+userId,details,{headers:headers});
  }
 
  //done///
  createProduct(details:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.post(this.serverName+'/api/manufacturers/product',details,{headers:headers});
  }
  //done//
  updateProduct(id:any,details:any):Observable<any> {
  
    // const authToken = this.authService.getToken();
    // let headers = new HttpHeaders();
    // headers = headers.set('Content-Type', 'application/json');
    // headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.put(this.serverName+'/api/manufacturers/product/'+id,details);
  }
  
  addInventory(details:any,productId:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.post(this.serverName+'/api/wholesalers/inventories?productId='+productId,details,{headers:headers});
  }
  
  updateInventory(stockQuantity:any,inventoryId:any):Observable<any> {
  
    const authToken = this.authService.getToken();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Authorization', `Bearer ${authToken}`);
    return this.http.put(this.serverName+`/api/wholesalers/inventories/${inventoryId}?stockQuantity=`+stockQuantity,{headers:headers});
  }

  Login(details:any):Observable<any> {
    
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    return this.http.post(this.serverName+'/api/user/login',details,{headers:headers});
  }
  registerUser(details:any):Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json');
    return this.http.post(this.serverName+'/api/user/register',details,{headers:headers});
  }
 
 


deleteProduct(productId: any): Observable<any>
    {
      console.log("Inside Http Service");
      let headers = new HttpHeaders();
      headers = headers.set('Content-Type', 'application/json');
     
      const token = localStorage.getItem('authToken'); 
          if (token)
          {
            headers = headers.set('Authorization', `Bearer ${token}`);
          }
          console.log("Inside Http Service 2");
      return this.http.delete(`${this.serverName}/api/manufacturers/product/${productId}`, {headers : headers});
     
    }
  
}












