export const environment = {
    // production: false,
    apiUrl: window.origin.replace("3000", "5000")+"/proxy/5000"
  
  };
  
