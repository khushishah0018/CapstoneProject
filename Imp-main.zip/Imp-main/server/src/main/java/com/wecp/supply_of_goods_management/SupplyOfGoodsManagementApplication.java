package com.wecp.supply_of_goods_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplyOfGoodsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplyOfGoodsManagementApplication.class, args);
	}

}
